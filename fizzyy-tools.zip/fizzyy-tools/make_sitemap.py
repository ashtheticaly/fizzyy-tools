"""Regenerates sitemap.xml and robots.txt. Edit SITE to your real address, then run: python3 make_sitemap.py"""
import json
SITE="https://YOUR-DOMAIN.example"  # change after deploying
pages=["index.html","about.html","contact.html","privacy.html","terms.html","affiliate-disclosure.html"]
tools=json.load(open("data/tools.json"))
urls=[f"{SITE}/{p}" for p in pages]+[f"{SITE}/tool.html?id={t['id']}" for t in tools]
open("sitemap.xml","w").write('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+"".join(f"<url><loc>{u}</loc></url>\n" for u in urls)+"</urlset>\n")
open("robots.txt","w").write(f"User-agent: *\nAllow: /\nSitemap: {SITE}/sitemap.xml\n")
