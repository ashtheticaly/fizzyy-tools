(()=>{
const CATS={writing:"AI Writing",image:"AI Image Generators",video:"AI Video Tools",audio:"AI Audio and Voice",coding:"AI Coding",productivity:"AI Productivity",education:"AI Education",business:"AI Business",design:"AI Design",research:"AI Research"};
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
let favs=[];try{favs=JSON.parse(localStorage.getItem("fz_favs")||"[]")}catch(e){}
const isFav=id=>favs.includes(id);
const PN={Free:"Free to use. Check the official site for any conditions.",Freemium:"Has a free plan with limits. Some features need a paid plan.",Paid:"Paid product. Check the official site for current plans and any trial."};
const badge=t=>`<span class="badge ${t.pricing.toLowerCase()}">${t.pricing}</span>${t.sponsored?'<span class="badge spons">Sponsored</span>':""}`;
const heart=(t,long)=>`<button class="${long?"btn ghost ":""}fav" data-fav="${t.id}" ${long?'data-long="1" ':""}aria-pressed="${isFav(t.id)}" aria-label="Save ${esc(t.name)} to favorites">${isFav(t.id)?"♥":"♡"}${long?(isFav(t.id)?" Saved":" Save"):""}</button>`;
const card=t=>`<article class="card"><div class="row">${badge(t)}${heart(t)}</div><h3><a href="tool.html?id=${t.id}">${esc(t.name)}</a></h3><p>${esc(t.desc)}</p><p class="cat">${CATS[t.cat]}</p></article>`;
const grid=(s,l)=>{$(s).innerHTML=l.map(card).join("")};

document.addEventListener("click",e=>{const b=e.target.closest("[data-fav]");if(!b)return;const id=b.dataset.fav;
 favs=isFav(id)?favs.filter(x=>x!==id):[...favs,id];try{localStorage.setItem("fz_favs",JSON.stringify(favs))}catch(x){}
 $$(`[data-fav="${id}"]`).forEach(x=>{const on=isFav(id);x.setAttribute("aria-pressed",on);x.textContent=(on?"♥":"♡")+(x.dataset.long?(on?" Saved":" Save"):"")});
 if(window.fzRun&&$("#favonly").checked)window.fzRun()});
const mb=$(".menu");mb.addEventListener("click",()=>{const o=$("#nav").classList.toggle("open");mb.setAttribute("aria-expanded",o)});

function home(T){
 const pop=[...T].sort((a,b)=>b.pop-a.pop);
 grid("#featured",pop.slice(0,6));grid("#popular",pop.slice(6,12));grid("#recent",T.slice(-6).reverse());
 grid("#free",[...T.filter(t=>t.pricing==="Free"),...T.filter(t=>t.pricing==="Freemium")].slice(0,6));
 $("#cats").innerHTML=Object.entries(CATS).map(([k,v])=>`<a class="catcard" href="#directory" data-cat="${k}"><strong>${v}</strong><span>${T.filter(t=>t.cat===k).length} tools</span></a>`).join("");
 const q=$("#q"),c=$("#cat"),p=$("#price"),s=$("#sort"),f=$("#favonly");
 c.innerHTML='<option value="">All categories</option>'+Object.entries(CATS).map(([k,v])=>`<option value="${k}">${v}</option>`).join("");
 const run=window.fzRun=()=>{const w=q.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
  let L=T.filter(t=>(!c.value||t.cat===c.value)&&(!p.value||t.pricing===p.value)&&(!f.checked||isFav(t.id)));
  if(w.length)L=L.filter(t=>{const h=[t.name,t.desc,CATS[t.cat],...t.features,...t.uses].join(" ").toLowerCase();return w.every(x=>h.includes(x))});
  L.sort(s.value==="name"?(a,b)=>a.name.localeCompare(b.name):(a,b)=>b.pop-a.pop);
  $("#count").textContent=`${L.length} tool${L.length===1?"":"s"} found`;
  $("#results").innerHTML=L.length?L.map(card).join(""):'<p class="empty">No tools match. Clear a filter or try a different keyword.</p>'};
 [q,c,p,s,f].forEach(e=>e.addEventListener("input",run));
 $("#heroform").addEventListener("submit",e=>{e.preventDefault();run();$("#directory").scrollIntoView()});
 $("#cats").addEventListener("click",e=>{const a=e.target.closest("[data-cat]");if(a){c.value=a.dataset.cat;run()}});
 $("#clear").addEventListener("click",()=>{q.value=c.value=p.value="";f.checked=false;s.value="pop";run()});
 const u=new URLSearchParams(location.search);if(u.get("fav"))f.checked=true;if(u.get("price"))p.value=u.get("price");if(CATS[u.get("cat")])c.value=u.get("cat");
 run();
}
function tool(T){
 const t=T.find(x=>x.id===new URLSearchParams(location.search).get("id")),m=$("#tool");
 if(!t){m.innerHTML='<h1>Tool not found</h1><p><a href="index.html#directory">Browse the directory</a></p>';document.title="Tool not found | Fizzyy Tools";return}
 document.title=`${t.name}: features, pricing and limits | Fizzyy Tools`;
 const d=`${t.desc} See features, pros, limitations and pricing type for ${t.name}.`;
 $("meta[name=description]").content=d;$('meta[property="og:title"]').content=document.title;$('meta[property="og:description"]').content=d;
 const li=a=>a.map(x=>`<li>${esc(x)}</li>`).join("");
 const link=t.affiliate||t.url,rel=t.affiliate?"sponsored noopener noreferrer":"noopener noreferrer";
 const rl=T.filter(x=>x.cat===t.cat&&x.id!==t.id).slice(0,3);
 m.innerHTML=`<p class="crumbs"><a href="index.html">Home</a> / <a href="index.html?cat=${t.cat}#directory">${CATS[t.cat]}</a></p>
 <div class="row">${badge(t)}</div><h1>${esc(t.name)}</h1><p class="lead">${esc(t.desc)}</p>
 <div class="actions"><a class="btn" href="${esc(link)}" target="_blank" rel="${rel}">Visit official website</a>${heart(t,1)}</div>
 ${t.affiliate?'<p class="note">This button is an affiliate link. See the <a href="affiliate-disclosure.html">Affiliate Disclosure</a>.</p>':""}
 <aside class="ad-slot" data-ad-slot hidden aria-label="Advertisement"></aside>
 <div class="cols"><div class="box"><h2>Main features</h2><ul>${li(t.features)}</ul></div><div class="box"><h2>Pros</h2><ul>${li(t.pros)}</ul></div><div class="box"><h2>Limitations</h2><ul>${li(t.limits)}</ul></div><div class="box"><h2>Suitable use cases</h2><ul>${li(t.uses)}</ul></div></div>
 <div class="box" style="margin-top:16px"><h2>Pricing</h2><p><strong>${t.pricing}.</strong> ${PN[t.pricing]}</p><p class="note">${t.verified?"Pricing last verified: "+esc(t.verified):"Pricing not yet verified by Fizzyy Tools. Confirm current plans on the official website."}</p></div>
 <section><h2>More in ${CATS[t.cat]}</h2><div class="grid" id="rel">${rl.map(card).join("")}</div></section>`;
}
const pg=document.body.dataset.page;
if(pg==="home"||pg==="tool")fetch("data/tools.json").then(r=>r.json()).then(T=>pg==="home"?home(T):tool(T)).catch(()=>{const e=$("#main");e.insertAdjacentHTML("afterbegin",'<p class="page">Could not load tool data. Serve the site over http (see README) instead of opening the file directly.</p>')});
})();
